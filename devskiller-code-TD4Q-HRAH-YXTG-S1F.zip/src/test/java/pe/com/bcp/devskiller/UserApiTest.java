package pe.com.bcp.devskiller;

import net.serenitybdd.core.environment.EnvironmentSpecificConfiguration;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import net.thucydides.core.environment.SystemEnvironmentVariables;
import net.thucydides.core.util.EnvironmentVariables;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import java.util.logging.Level;
import java.util.logging.Logger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(SerenityJUnit5Extension.class)
public class UserApiTest extends BaseTest {

    private final EnvironmentVariables variables = SystemEnvironmentVariables.createEnvironmentVariables();
    private static String URL_USER;
    public static final int PAGE_NUMBER = 0;

    @BeforeEach
    public void getProperties() {
        URL_USER = EnvironmentSpecificConfiguration.from(variables).getProperty("url.api.user");
    }

    /**
     * <b>¡¡¡ IMPORTANTE !!!</b>
     * <p>
     * * Este test debe validar que la url base enviada sea la correcta
     * * Valida la URL BASE en el contrato del servicio
     */
    @Test
    public void validarURLBase() {
        Logger.getAnonymousLogger().log(Level.INFO, "Url base --> {0}", URL_USER);

        assertTrue(URL_USER.contains("/users"),
                "La URL enviada no contiene el endpoint '/users'.");
    }

    /**
     * <b>¡¡¡ IMPORTANTE !!!</b>
     * <p>
     * * Este test debe validar que el estado de respuesta del servicio sea correcto
     * <p>
     * * Valida el estado de respuesta en el contrato del servicio
     * <p>
     * * <b>De ser necesario, cambiar el valor de la constante 'PAGE_NUMBER'</b>
     */
    @Test
    public void validarCodigoDeRespuesta() {
        Logger.getAnonymousLogger().log(Level.INFO, "Page Number --> {0}", PAGE_NUMBER);

        assertEquals(400,
                getListByPage(PAGE_NUMBER, URL_USER).statusCode(),
                "El código de estado de respuesta obtenido no es el esperado.");
    }

    /**
     * <b>¡¡¡ IMPORTANTE !!!</b>
     * <p>
     * * Este test debe validar que el número de página consultada sea la indicada en el ejercicio
     * <p>
     * * <b>Utiliza JSON_PATH para encontrar el valor en la respuesta</b>
     */
    @Test
    public void validarNumeroPaginaEnRespuesta() {
        assertEquals(PAGE_NUMBER,
                getPageFromResponse(PAGE_NUMBER, URL_USER),
                "El número de paginación no es el mismo enviado en el query del servicio.");
    }

}