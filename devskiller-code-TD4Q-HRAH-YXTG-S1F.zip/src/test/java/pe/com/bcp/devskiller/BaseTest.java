package pe.com.bcp.devskiller;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BaseTest {

    /**
     * <b>¡¡¡ IMPORTANTE !!!</b>
     * <p>
     * Este método configura la petición del servicio, de tal forma que puedas obtener la lista de usuarios páginados.
     * <p>
     * <b>* Valida en el contrato del servicio que tipo parametro es el correcto para esta petición</b>
     * <p>
     * @param pageNumber Número de página solicitada
     * @return la especificación de la petición configurada
     */
    private RequestSpecification requestService(int pageNumber) {
        return RestAssured.given()
                .contentType("application/json")
                .pathParams("", pageNumber);
    }

    /**
     * <b>Este método ejecuta el método HTTP solicitado en el desafio y <p>
     * obtiene la lista de usuarios a partir de la petición configurada en el método:</b>
     * <p>
     * -->  requestService(page);
     * <p>
     * @param pageNumber Número de página solicitada
     * @param urlUser    url base compuesta del servicio users
     * @return la respuesta del servicio si la petición es la correcta.
     */
    public Response getListByPage(int pageNumber, String urlUser) {
        Response response = requestService(pageNumber)
                .when().log().all()
                .get(urlUser);
        return response.prettyPeek();
    }

    /**
     * <b>Este método obtiene le valor del campo que se desea validar <p>
     * a través de la técnica de localización JSON PATH</b>
     * <p>
     * <p>
     * @param pageNumber Número de página solicitada
     * @param urlUser    url base compuesta del servicio users
     * @return el valor del campo que se obtiene desde la respuesta del servicio
     */
    public int getPageFromResponse(int pageNumber, String urlUser){
        return getListByPage(pageNumber, urlUser).getBody().jsonPath().getInt("<json-path>");
    }


}
